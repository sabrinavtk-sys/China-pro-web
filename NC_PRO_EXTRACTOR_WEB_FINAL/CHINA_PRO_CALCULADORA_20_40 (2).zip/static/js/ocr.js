(() => {
    "use strict";

    console.log("OCR.JS v58 CARREGADO");

    // =========================================================
    // ESTADO PRIVADO
    // =========================================================

    let ocrEmProcessamento = false;
    let promessaTesseract = null;

    const URLS_TESSERACT = [
        "https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js",
        "https://unpkg.com/tesseract.js@5/dist/tesseract.min.js"
    ];

    const RECORTES_RECEBIMENTO = [
        /*
            PRIORIDADE MÁXIMA:
            notificação azul do canto superior esquerdo.
            Exemplo real:
            "Você recebeu o item x829316 DINHEIRO SUJO
             de Davi Knecht [145156]"

            O recorte pequeno evita que personagens, HUD, veículos
            e o balão inferior confundam o Tesseract.
        */
        {
            nome: "NOTIFICAÇÃO RECEBIMENTO RAW",
            x: 0.006,
            y: 0.105,
            largura: 0.31,
            altura: 0.115,
            escala: 5.2,
            filtro: "nenhum",
            psm: "6"
        },
        {
            nome: "NOTIFICAÇÃO RECEBIMENTO CINZA",
            x: 0.006,
            y: 0.105,
            largura: 0.31,
            altura: 0.115,
            escala: 5.2,
            filtro: "cinza",
            psm: "6"
        },
        {
            nome: "NOTIFICAÇÃO RECEBIMENTO BINÁRIO",
            x: 0.006,
            y: 0.105,
            largura: 0.31,
            altura: 0.115,
            escala: 5.2,
            filtro: "binario",
            limiar: 145,
            psm: "6"
        },
        {
            nome: "BALÃO AMPLO COLORIDO",
            x: 0.00,
            y: 0.05,
            largura: 0.90,
            altura: 0.50,
            escala: 2.2,
            filtro: "colorido",
            psm: "6"
        },
        {
            nome: "BALÃO AMPLO CINZA",
            x: 0.00,
            y: 0.05,
            largura: 0.90,
            altura: 0.50,
            escala: 2.2,
            filtro: "cinza",
            psm: "6"
        },
        {
            nome: "BALÃO FOCADO CINZA",
            x: 0.00,
            y: 0.11,
            largura: 0.80,
            altura: 0.34,
            escala: 3.2,
            filtro: "cinza",
            psm: "6"
        },
        {
            nome: "BALÃO FOCADO BINÁRIO",
            x: 0.00,
            y: 0.11,
            largura: 0.80,
            altura: 0.34,
            escala: 3.2,
            filtro: "binario",
            limiar: 150,
            psm: "6"
        }
    ];

    // =========================================================
    // ELEMENTOS E CONSOLE
    // =========================================================

    function obterElemento(id) {
        return document.getElementById(id);
    }

    function atualizarConsoleOCR(texto) {
        const elemento = obterElemento("resultadoOCR");

        if (elemento) {
            elemento.textContent = String(texto ?? "");
        }
    }

    function atualizarBotaoProcessar(processando) {
        const botao = obterElemento("btnProcessar");

        if (!botao) {
            return;
        }

        botao.disabled = processando;

        botao.innerHTML = processando
            ? `
                <span class="btn-processar-icone">⏳</span>
                <span class="btn-processar-texto">
                    <strong>PROCESSANDO OCR...</strong>
                    <small>Aguarde a análise dos prints</small>
                </span>
            `
            : `
                <span class="btn-processar-icone">🤖</span>
                <span class="btn-processar-texto">
                    <strong>PROCESSAR OCR</strong>
                    <small>Iniciar análise dos dois prints</small>
                </span>
            `;
    }

    function mostrarProgresso(etapa, progresso) {
        const porcentagem = Math.max(
            0,
            Math.min(100, Math.round((Number(progresso) || 0) * 100))
        );

        console.log(`${etapa}: ${porcentagem}%`);
        atualizarConsoleOCR(`${etapa}\n\nProcessando: ${porcentagem}%`);
    }

    // =========================================================
    // TESSERACT
    // =========================================================

    function carregarScript(url) {
        return new Promise((resolve, reject) => {
            const seletor = `script[data-ocr-tesseract="${url}"]`;
            const existente = document.querySelector(seletor);

            if (existente) {
                if (
                    window.Tesseract &&
                    typeof window.Tesseract.recognize === "function"
                ) {
                    resolve(window.Tesseract);
                    return;
                }

                existente.addEventListener(
                    "load",
                    () => resolve(window.Tesseract),
                    { once: true }
                );

                existente.addEventListener(
                    "error",
                    () => reject(new Error(`Falha ao carregar ${url}`)),
                    { once: true }
                );

                return;
            }

            const script = document.createElement("script");
            script.src = url;
            script.async = true;
            script.dataset.ocrTesseract = url;

            script.onload = () => {
                if (
                    window.Tesseract &&
                    typeof window.Tesseract.recognize === "function"
                ) {
                    resolve(window.Tesseract);
                    return;
                }

                reject(
                    new Error(
                        "O Tesseract.js foi carregado, mas não disponibilizou a função recognize."
                    )
                );
            };

            script.onerror = () => {
                script.remove();
                reject(new Error(`Falha ao carregar ${url}`));
            };

            document.head.appendChild(script);
        });
    }

    async function garantirTesseractCarregado() {
        if (
            window.Tesseract &&
            typeof window.Tesseract.recognize === "function"
        ) {
            return window.Tesseract;
        }

        if (promessaTesseract) {
            return promessaTesseract;
        }

        promessaTesseract = (async () => {
            let ultimoErro = null;

            for (const url of URLS_TESSERACT) {
                try {
                    const biblioteca = await carregarScript(url);

                    console.log("TESSERACT.JS CARREGADO:", url);
                    return biblioteca;
                } catch (erro) {
                    ultimoErro = erro;
                    console.warn("FALHA NO CDN DO TESSERACT:", url, erro);
                }
            }

            throw (
                ultimoErro ||
                new Error("Não foi possível carregar o Tesseract.js.")
            );
        })();

        try {
            return await promessaTesseract;
        } catch (erro) {
            promessaTesseract = null;
            throw erro;
        }
    }

    // =========================================================
    // IMAGEM E CANVAS
    // =========================================================

    function carregarImagemArquivo(arquivo) {
        return new Promise((resolve, reject) => {
            if (!arquivo) {
                reject(new Error("Arquivo de imagem não informado."));
                return;
            }

            if (!arquivo.type || !arquivo.type.startsWith("image/")) {
                reject(new Error("O arquivo selecionado não é uma imagem válida."));
                return;
            }

            const leitor = new FileReader();
            const imagem = new Image();

            leitor.onload = evento => {
                imagem.src = String(evento.target?.result || "");
            };

            leitor.onerror = () => {
                reject(new Error("Não foi possível ler o arquivo."));
            };

            imagem.onload = () => resolve(imagem);

            imagem.onerror = () => {
                reject(new Error("Não foi possível abrir a imagem."));
            };

            leitor.readAsDataURL(arquivo);
        });
    }

    function clonarCanvas(canvasOriginal) {
        const canvas = document.createElement("canvas");

        canvas.width = canvasOriginal.width;
        canvas.height = canvasOriginal.height;

        const contexto = canvas.getContext("2d", {
            willReadFrequently: true
        });

        if (!contexto) {
            throw new Error(
                "O navegador não conseguiu criar o contexto 2D."
            );
        }

        contexto.drawImage(
            canvasOriginal,
            0,
            0
        );

        return canvas;
    }    function criarCanvasRecorte(imagem, configuracao) {
        const larguraImagem = imagem.naturalWidth || imagem.width;
        const alturaImagem = imagem.naturalHeight || imagem.height;

        const x = Math.round(
            larguraImagem * configuracao.x
        );

        const y = Math.round(
            alturaImagem * configuracao.y
        );

        const largura = Math.max(
            1,
            Math.min(
                larguraImagem - x,
                Math.round(
                    larguraImagem *
                    configuracao.largura
                )
            )
        );

        const altura = Math.max(
            1,
            Math.min(
                alturaImagem - y,
                Math.round(
                    alturaImagem *
                    configuracao.altura
                )
            )
        );

        const escala =
            Number(configuracao.escala) || 1;

        const canvas =
            document.createElement("canvas");

        canvas.width = Math.max(
            1,
            Math.round(
                largura * escala
            )
        );

        canvas.height = Math.max(
            1,
            Math.round(
                altura * escala
            )
        );

        const contexto = canvas.getContext(
            "2d",
            {
                willReadFrequently: true
            }
        );

        if (!contexto) {
            throw new Error(
                "O navegador não conseguiu criar o contexto 2D."
            );
        }

        contexto.imageSmoothingEnabled = true;
        contexto.imageSmoothingQuality = "high";

        contexto.drawImage(
            imagem,
            x,
            y,
            largura,
            altura,
            0,
            0,
            canvas.width,
            canvas.height
        );

        return canvas;
    }

    function aplicarCinza(
        canvas,
        contraste = 1.45
    ) {
        const contexto = canvas.getContext(
            "2d",
            {
                willReadFrequently: true
            }
        );

        if (!contexto) {
            throw new Error(
                "Não foi possível processar a imagem em cinza."
            );
        }

        const dados = contexto.getImageData(
            0,
            0,
            canvas.width,
            canvas.height
        );

        const pixels = dados.data;

        for (
            let indice = 0;
            indice < pixels.length;
            indice += 4
        ) {
            const vermelho =
                pixels[indice];

            const verde =
                pixels[indice + 1];

            const azul =
                pixels[indice + 2];

            let cinza =
                vermelho * 0.299 +
                verde * 0.587 +
                azul * 0.114;

            cinza =
                (cinza - 128) *
                contraste +
                128;

            cinza = Math.max(
                0,
                Math.min(
                    255,
                    cinza
                )
            );

            pixels[indice] =
                cinza;

            pixels[indice + 1] =
                cinza;

            pixels[indice + 2] =
                cinza;
        }

        contexto.putImageData(
            dados,
            0,
            0
        );

        return canvas;
    }

    function aplicarBinario(
        canvas,
        limiar = 150
    ) {
        const contexto = canvas.getContext(
            "2d",
            {
                willReadFrequently: true
            }
        );

        if (!contexto) {
            throw new Error(
                "Não foi possível binarizar a imagem."
            );
        }

        const dados = contexto.getImageData(
            0,
            0,
            canvas.width,
            canvas.height
        );

        const pixels = dados.data;

        for (
            let indice = 0;
            indice < pixels.length;
            indice += 4
        ) {
            const brilho =
                pixels[indice] * 0.299 +
                pixels[indice + 1] * 0.587 +
                pixels[indice + 2] * 0.114;

            const valor =
                brilho >= limiar
                    ? 255
                    : 0;

            pixels[indice] =
                valor;

            pixels[indice + 1] =
                valor;

            pixels[indice + 2] =
                valor;
        }

        contexto.putImageData(
            dados,
            0,
            0
        );

        return canvas;
    }

    function aplicarFiltro(
        canvas,
        configuracao
    ) {
        if (
            configuracao.filtro ===
            "cinza"
        ) {
            return aplicarCinza(
                canvas,
                1.55
            );
        }

        if (
            configuracao.filtro ===
            "binario"
        ) {
            return aplicarBinario(
                aplicarCinza(
                    canvas,
                    1.35
                ),
                configuracao.limiar ||
                150
            );
        }

        return canvas;
    }

    // =========================================================
    // OCR
    // =========================================================

    async function reconhecerTexto(
        canvas,
        etapa,
        psm = "6"
    ) {
        const Tesseract =
            await garantirTesseractCarregado();

        console.log(
            "INICIANDO OCR:",
            etapa
        );

        const resultado =
            await Tesseract.recognize(
                canvas,
                "por",
                {
                    logger: mensagem => {
                        if (
                            mensagem.status ===
                            "recognizing text"
                        ) {
                            mostrarProgresso(
                                etapa,
                                mensagem.progress
                            );
                        }
                    },

                    tessedit_pageseg_mode:
                        psm,

                    preserve_interword_spaces:
                        "1"
                }
            );

        return {
            nome:
                etapa,

            texto:
                resultado?.data?.text ||
                "",

            confianca:
                Number(
                    resultado?.data?.confidence
                ) || 0
        };
    }

    async function lerPrintEnvio(
        arquivo
    ) {
        const imagem =
            await carregarImagemArquivo(
                arquivo
            );

        /*
            O balão verde fica no canto superior esquerdo.
            Fazemos várias leituras do MESMO local sem jamais
            incluir o saldo do canto superior direito.
        */
        const configuracoes = [
            {
                nome: "ENVIO VERDE RAW PSM6",
                x: 0.005,
                y: 0.095,
                largura: 0.31,
                altura: 0.14,
                escala: 5.0,
                filtro: "nenhum",
                psm: "6"
            },
            {
                nome: "ENVIO VERDE RAW PSM11",
                x: 0.005,
                y: 0.095,
                largura: 0.31,
                altura: 0.14,
                escala: 5.0,
                filtro: "nenhum",
                psm: "11"
            },
            {
                nome: "ENVIO VERDE CINZA PSM6",
                x: 0.005,
                y: 0.085,
                largura: 0.34,
                altura: 0.18,
                escala: 5.2,
                filtro: "cinza",
                psm: "6"
            },
            {
                nome: "ENVIO VERDE CINZA PSM11",
                x: 0.005,
                y: 0.085,
                largura: 0.34,
                altura: 0.18,
                escala: 5.2,
                filtro: "cinza",
                psm: "11"
            },
            {
                nome: "ENVIO VERDE BINARIO 120",
                x: 0.005,
                y: 0.085,
                largura: 0.34,
                altura: 0.18,
                escala: 5.5,
                filtro: "binario",
                limiar: 120,
                psm: "6"
            },
            {
                nome: "ENVIO VERDE BINARIO 150",
                x: 0.005,
                y: 0.085,
                largura: 0.34,
                altura: 0.18,
                escala: 5.5,
                filtro: "binario",
                limiar: 150,
                psm: "6"
            },
            {
                nome: "ENVIO VERDE BINARIO 180",
                x: 0.005,
                y: 0.085,
                largura: 0.34,
                altura: 0.18,
                escala: 5.5,
                filtro: "binario",
                limiar: 180,
                psm: "11"
            },
            {
                /*
                    Linha específica onde normalmente aparece
                    "Você enviou R$... para ...".
                */
                nome: "ENVIO LINHA DO VALOR",
                x: 0.012,
                y: 0.125,
                largura: 0.29,
                altura: 0.075,
                escala: 6.0,
                filtro: "cinza",
                psm: "7"
            },
            {
                nome: "ENVIO TOPO ESQUERDO SEGURO",
                x: 0,
                y: 0.05,
                largura: 0.42,
                altura: 0.28,
                escala: 3.6,
                filtro: "cinza",
                psm: "11"
            }
        ];

        const leituras = [];

        for(
            const configuracao
            of configuracoes
        ){
            const recorte =
                criarCanvasRecorte(
                    imagem,
                    configuracao
                );

            let processado =
                clonarCanvas(
                    recorte
                );

            if(
                configuracao.filtro !==
                "nenhum"
            ){
                processado =
                    aplicarFiltro(
                        processado,
                        configuracao
                    );
            }

            const leitura =
                await reconhecerTexto(
                    processado,
                    configuracao.nome,
                    configuracao.psm
                );

            console.log(
                configuracao.nome + ":",
                leitura.texto
            );

            leituras.push(
                leitura
            );

            if(
                typeof window.pegarValorEnvio ===
                "function"
            ){
                const valorDetectado =
                    window.pegarValorEnvio(
                        leitura.texto
                    );

                if(
                    Number(valorDetectado) > 0
                ){
                    console.log(
                        "ENVIO CONFIRMADO NO RECORTE:",
                        {
                            valor:
                                valorDetectado,
                            leitura:
                                configuracao.nome
                        }
                    );

                    return {
                        nome:
                            configuracao.nome,
                        texto:
                            leitura.texto,
                        confianca:
                            leitura.confianca
                    };
                }
            }
        }

        /*
            Última tentativa: combina APENAS os textos
            provenientes da região segura do balão verde.
        */
        const textoCombinado =
            leituras
            .map(
                leitura =>
                    leitura.texto
            )
            .filter(Boolean)
            .join("\n");

        if(
            typeof window.pegarValorEnvio ===
            "function"
        ){
            const valorCombinado =
                window.pegarValorEnvio(
                    textoCombinado
                );

            if(
                Number(valorCombinado) > 0
            ){
                console.log(
                    "ENVIO CONFIRMADO NAS LEITURAS COMBINADAS:",
                    valorCombinado
                );

                return {
                    nome:
                        "ENVIO - CONSENSO BALÃO VERDE",
                    texto:
                        textoCombinado,
                    confianca:
                        Math.max(
                            0,
                            ...leituras.map(
                                leitura =>
                                    Number(
                                        leitura.confianca
                                    ) || 0
                            )
                        )
                };
            }
        }

        return {
            nome:
                "ENVIO - BALÃO VERDE NÃO IDENTIFICADO",
            texto:
                textoCombinado,
            confianca:
                0
        };
    }

    // =========================================================
    // DATA E HORA DO RODAPÉ DO PRINT FINAL
    // Ex.: ID: 768 - 25/07/2026 - 23:41 - PING: ...
    // =========================================================

    async function lerRodapeDataHora(
        arquivo
    ){
        const imagem =
            await carregarImagemArquivo(
                arquivo
            );

        const configuracoes = [
            {
                nome:
                    "RODAPÉ DATA/HORA CINZA",
                x: 0.52,
                y: 0.90,
                largura: 0.48,
                altura: 0.10,
                escala: 4.0,
                filtro: "cinza",
                psm: "7"
            },
            {
                nome:
                    "RODAPÉ DATA/HORA BINÁRIO",
                x: 0.52,
                y: 0.90,
                largura: 0.48,
                altura: 0.10,
                escala: 4.0,
                filtro: "binario",
                limiar: 145,
                psm: "7"
            }
        ];

        const leituras = [];

        for(
            const configuracao
            of configuracoes
        ){
            const recorte =
                criarCanvasRecorte(
                    imagem,
                    configuracao
                );

            const processado =
                aplicarFiltro(
                    recorte,
                    configuracao
                );

            leituras.push(
                await reconhecerTexto(
                    processado,
                    configuracao.nome,
                    configuracao.psm
                )
            );
        }

        for(
            const leitura
            of leituras
        ){
            const data =
                typeof window.pegarData === "function"
                    ? window.pegarData(
                        leitura.texto
                    )
                    : "---";

            if(
                data &&
                data !== "---"
            ){
                return {
                    data,
                    texto:
                        leitura.texto,
                    leitura:
                        leitura.nome
                };
            }
        }

        return {
            data: "---",
            texto:
                leituras
                .map(x => x.texto)
                .join("\n"),
            leitura:
                "não identificada"
        };
    }


    async function lerVariacoesRecebimento(
        arquivo
    ) {
        const imagem =
            await carregarImagemArquivo(
                arquivo
            );

        const leituras = [];

        for (
            const configuracao
            of RECORTES_RECEBIMENTO
        ) {
            const recorte =
                criarCanvasRecorte(
                    imagem,
                    configuracao
                );

            const processado =
                aplicarFiltro(
                    clonarCanvas(
                        recorte
                    ),
                    configuracao
                );

            const leitura =
                await reconhecerTexto(
                    processado,
                    configuracao.nome,
                    configuracao.psm
                );

            console.log(
                configuracao.nome
            );

            console.log(
                leitura.texto
            );

            leituras.push(
                leitura
            );
        }

        return leituras;
    }

    // =========================================================
    // PONTUAÇÃO E CONSENSO
    // =========================================================

    function normalizarTextoOCR(
        texto
    ) {
        return String(
            texto || ""
        )
        .normalize(
            "NFD"
        )
        .replace(
            /[\u0300-\u036f]/g,
            ""
        )
        .toLowerCase()
        .replace(
            /\s+/g,
            " "
        )
        .trim();
    }

    function pontuarTextoBalao(
        texto,
        confiancaTesseract = 0
    ) {
        const normalizado =
            normalizarTextoOCR(
                texto
            );

        let pontos =
            Math.min(
                20,
                confiancaTesseract / 5
            );

        /*
            Uma frase explícita "Você recebeu..." é mais confiável
            que um número solto do HUD/balão inferior.
        */
        if (
            /voce\s+receb|recebeu\s+(?:o\s+)?item/.test(
                normalizado
            )
        ) {
            pontos += 65;
        }

        if (
            /dinheiro|d[il1]nheiro|di\s*nhei\s*ro/.test(
                normalizado
            )
        ) {
            pontos += 28;
        }

        if (
            /receb|recebeu|recebido|recebes|rcebeu/.test(
                normalizado
            )
        ) {
            pontos += 22;
        }

        if (
            /item|tem|oiem|olem|ltem/.test(
                normalizado
            )
        ) {
            pontos += 10;
        }

        if (
            /sujo|suko|sulo|hl\/o|hlo|hl0/.test(
                normalizado
            )
        ) {
            pontos += 16;
        }

        if (
            /[x×«]\s*[\d\s.,]{4,}/.test(
                normalizado
            )
        ) {
            pontos += 22;
        }

        if (
            /\[\s*\d{3,8}\s*\]/.test(
                normalizado
            )
        ) {
            pontos += 10;
        }

        if (
            /anuncio|saldo|banco|pix/.test(
                normalizado
            )
        ) {
            pontos -= 15;
        }

        return pontos;
    }

    function analisarLeitura(
        textoEnvio,
        leitura
    ) {
        if (
            typeof window.parseOCR !==
            "function"
        ) {
            throw new Error(
                "A função parseOCR não foi carregada. Verifique o parser.js."
            );
        }

        const resultado =
            window.parseOCR(
                textoEnvio,
                leitura.texto
            );

        const valorEnvio =
            Number(
                resultado?.envio
            ) || 0;

        const valorRecebido =
            Number(
                resultado?.recebido
            ) || 0;

        let pontuacao =
            pontuarTextoBalao(
                leitura.texto,
                leitura.confianca
            );

        if (
            valorRecebido > 0
        ) {
            pontuacao += 38;
        }

        if (
            resultado?.nome &&
            resultado.nome !==
            "Não identificado"
        ) {
            pontuacao += 16;
        }

        if (
            resultado?.idJogador &&
            resultado.idJogador !==
            "---"
        ) {
            pontuacao += 13;
        }

        if (
            resultado?.data &&
            resultado.data !==
            "---"
        ) {
            pontuacao += 5;
        }

        if (
            Number(
                resultado?.confiancaValor
            ) > 0
        ) {
            pontuacao += Math.min(
                20,
                Number(
                    resultado.confiancaValor
                ) / 5
            );
        }

        if (
            valorEnvio > 0 &&
            valorRecebido <= valorEnvio
        ) {
            pontuacao -= 120;
        }

        if (
            valorEnvio > 0 &&
            valorRecebido > valorEnvio
        ) {
            const percentual =
                (
                    (
                        valorRecebido -
                        valorEnvio
                    )
                    /
                    valorRecebido
                )
                * 100;

            if(
                percentual >= 20 &&
                percentual <= 40
            ){
                pontuacao += 80;
            }
            else{
                pontuacao -= 100;
            }
        }

        return {
            ...leitura,
            resultado,
            pontuacao
        };
    }

    function aplicarConsenso(
        leituras
    ) {
        const contagem =
            new Map();

        for (
            const leitura
            of leituras
        ) {
            const valor =
                Number(
                    leitura.resultado
                        ?.recebido
                ) || 0;

            if (
                valor <= 0
            ) {
                continue;
            }

            contagem.set(
                valor,
                (
                    contagem.get(
                        valor
                    ) || 0
                ) + 1
            );
        }

        for (
            const leitura
            of leituras
        ) {
            const valor =
                Number(
                    leitura.resultado
                        ?.recebido
                ) || 0;

            const repeticoes =
                contagem.get(
                    valor
                ) || 0;

            if (
                repeticoes >= 2
            ) {
                leitura.pontuacao +=
                    repeticoes * 22;
            }
        }

        return leituras;
    }    function escolherMelhorLeitura(
        textoEnvio,
        leituras
    ) {
        const analisadas =
            aplicarConsenso(
                leituras.map(
                    leitura =>
                        analisarLeitura(
                            textoEnvio,
                            leitura
                        )
                )
            );

        analisadas.sort(
            (
                primeira,
                segunda
            ) =>
                segunda.pontuacao -
                primeira.pontuacao
        );

        console.table(
            analisadas.map(
                leitura => ({
                    leitura:
                        leitura.nome,

                    valor:
                        leitura.resultado
                            ?.recebido || 0,

                    nome:
                        leitura.resultado
                            ?.nome || "---",

                    id:
                        leitura.resultado
                            ?.idJogador || "---",

                    confiancaTesseract:
                        leitura.confianca,

                    pontuacao:
                        leitura.pontuacao
                })
            )
        );

        return analisadas[0] || null;
    }

    // =========================================================
    // RESULTADO E LIMPEZA
    // =========================================================

    function limparProcessamentoAnterior() {
        window.resultadoOCR = null;

        if (
            typeof window
                .limparDadosOperacao ===
            "function"
        ) {
            window.limparDadosOperacao();
        }
        else {
            const valores = {
                nomeJogador:
                    "---",

                idJogador:
                    "---",

                valorRecebido:
                    "R$ 0",

                valorPorcentagem:
                    "R$ 0,00"
            };

            for (
                const [id, valor]
                of Object.entries(
                    valores
                )
            ) {
                const elemento =
                    obterElemento(id);

                if (elemento) {
                    elemento.textContent =
                        valor;
                }
            }
        }

        atualizarConsoleOCR(
            "Preparando novo processamento..."
        );
    }

    function exibirResultadoOCR(
        resultado
    ) {
        const nome =
            obterElemento(
                "nomeJogador"
            );

        const id =
            obterElemento(
                "idJogador"
            );

        const data =
            obterElemento(
                "dataOperacao"
            );

        const valor =
            obterElemento(
                "valorRecebido"
            );

        if (nome) {
            nome.textContent =
                resultado.nome ||
                "Não identificado";
        }

        if (id) {
            id.textContent =
                resultado.idJogador ||
                "---";
        }

        if (
            data &&
            resultado.data &&
            resultado.data !== "---"
        ) {
            data.textContent =
                resultado.data;
        }

        const valorRecebido =
            Number(
                resultado.recebido
            ) || 0;

        if (valor) {
            valor.textContent =
                valorRecebido
                .toLocaleString(
                    "pt-BR",
                    {
                        style:
                            "currency",

                        currency:
                            "BRL",

                        minimumFractionDigits:
                            0,

                        maximumFractionDigits:
                            0
                    }
                );
        }

        if (
            typeof window
                .aplicarCalculoAutomatico ===
            "function"
        ) {
            window.aplicarCalculoAutomatico(
                Number(resultado.recebido) || 0,
                Number(resultado.envio) || 0
            );
        }
        else if (
            typeof window
                .calcularGanho ===
            "function"
        ) {
            window.calcularGanho();
        }

        atualizarConsoleOCR(
            JSON.stringify(
                resultado,
                null,
                4
            )
        );
    }

    // =========================================================
    // PROCESSAMENTO PRINCIPAL
    // =========================================================

    async function processarOCR() {
        if (ocrEmProcessamento) {
            console.warn(
                "OCR JÁ ESTÁ EM PROCESSAMENTO"
            );

            return;
        }

        const arquivoEnvio =
            obterElemento(
                "printEnvio"
            )
            ?.files?.[0];

        const arquivoRecebimento =
            obterElemento(
                "printRecebimento"
            )
            ?.files?.[0];

        if (
            !arquivoEnvio ||
            !arquivoRecebimento
        ) {
            alert(
                "Envie o print de envio e o print de recebimento."
            );

            return;
        }

        try {
            ocrEmProcessamento =
                true;

            atualizarBotaoProcessar(
                true
            );

            limparProcessamentoAnterior();

            console.log(
                "===================="
            );

            console.log(
                "INICIANDO PROCESSAMENTO OCR v58"
            );

            console.log(
                "ARQUIVO ENVIO:",
                arquivoEnvio.name,
                arquivoEnvio.size
            );

            console.log(
                "ARQUIVO RECEBIMENTO:",
                arquivoRecebimento.name,
                arquivoRecebimento.size
            );

            await garantirTesseractCarregado();

            const leituraEnvio =
                await lerPrintEnvio(
                    arquivoEnvio
                );

            const textoEnvio =
                leituraEnvio.texto;

            console.log(
                "TEXTO ENVIO"
            );

            console.log(
                textoEnvio
            );

            const leiturasRecebimento =
                await lerVariacoesRecebimento(
                    arquivoRecebimento
                );

            /*
                DATA/HORA FINAL:
                lê o rodapé dos DOIS prints e escolhe a data/hora
                cronologicamente mais recente.

                Isso evita depender da ordem em que o usuário colocou
                os prints. No caso real:
                  recebido -> 17/08/2026 17:59
                  enviado  -> 17/08/2026 18:00
                Resultado final correto -> 18:00.
            */
            const leituraRodapeEnvio =
                await lerRodapeDataHora(
                    arquivoEnvio
                );

            const leituraRodapeRecebimento =
                await lerRodapeDataHora(
                    arquivoRecebimento
                );

            function converterDataOCRParaTimestamp(
                valor
            ){
                const busca =
                    String(valor || "").match(
                        /^(\d{2})\/(\d{2})\/(\d{4})\s+(\d{2}):(\d{2})$/
                    );

                if(!busca){
                    return 0;
                }

                return Date.UTC(
                    Number(busca[3]),
                    Number(busca[2]) - 1,
                    Number(busca[1]),
                    Number(busca[4]),
                    Number(busca[5])
                );
            }

            const candidatosDataHora = [
                leituraRodapeEnvio,
                leituraRodapeRecebimento
            ].filter(
                leitura =>
                    leitura &&
                    leitura.data &&
                    leitura.data !== "---"
            );

            candidatosDataHora.sort(
                (a,b) =>
                    converterDataOCRParaTimestamp(b.data) -
                    converterDataOCRParaTimestamp(a.data)
            );

            const leituraRodape =
                candidatosDataHora[0] || {
                    data: "---",
                    texto: "",
                    leitura: "não identificada"
                };

            console.log(
                "DATA/HORA PRINT ENVIO:",
                leituraRodapeEnvio
            );

            console.log(
                "DATA/HORA PRINT RECEBIMENTO:",
                leituraRodapeRecebimento
            );

            console.log(
                "DATA/HORA FINAL ESCOLHIDA:",
                leituraRodape
            );

            const textoCombinado =
                leiturasRecebimento
                .map(
                    leitura =>
                        leitura.texto
                )
                .filter(Boolean)
                .join(
                    "\n\n"
                );

            leiturasRecebimento.push({
                nome:
                    "LEITURAS COMBINADAS",

                texto:
                    textoCombinado,

                confianca:
                    0
            });

            const melhor =
                escolherMelhorLeitura(
                    textoEnvio,
                    leiturasRecebimento
                );

            if (
                !melhor ||
                !melhor.resultado
            ) {
                throw new Error(
                    "Nenhuma leitura válida foi produzida."
                );
            }

            const resultadoBase =
                melhor.resultado;

            const valorRecebido =
                Number(
                    resultadoBase.recebido
                ) || 0;

            if (
                valorRecebido <= 0
            ) {
                throw new Error(
                    "Não foi possível identificar o valor do balão azul."
                );
            }

            const valorEnviado =
                Number(
                    resultadoBase.envio
                ) || 0;

            if(
                valorEnviado <= 0
            ){
                throw new Error(
                    "Não foi possível identificar o valor enviado no balão verde."
                );
            }

            if(
                valorRecebido <=
                valorEnviado
            ){

                console.error(
                    "VALORES INCOMPATÍVEIS:",
                    {
                        valorOriginalBalaoAzul:
                            valorRecebido,
                        valorEnviadoBalaoVerde:
                            valorEnviado,
                        leituraEnvio:
                            leituraEnvio?.nome,
                        textoEnvio:
                            textoEnvio
                    }
                );

                throw new Error(
                    "O valor lido no balão verde ficou maior que o valor original. O OCR do envio não foi confiável; tente processar novamente."
                );
            }

            const percentualBruto =
                (
                    (
                        valorRecebido -
                        valorEnviado
                    )
                    /
                    valorRecebido
                )
                * 100;

            /*
                As taxas da organização são inteiras.
                O OCR pode errar 1 ou 2 dígitos pequenos no valor,
                fazendo 20% aparecer como 19,97%, por exemplo.

                Se o resultado estiver muito perto de um inteiro,
                normalizamos para esse inteiro.
            */
            const percentualArredondado =
                Math.round(
                    percentualBruto
                );

            const distanciaDoInteiro =
                Math.abs(
                    percentualBruto -
                    percentualArredondado
                );

            const percentualAutomatico =
                distanciaDoInteiro <= 0.35
                    ? percentualArredondado
                    : Number(
                        percentualBruto
                            .toFixed(2)
                    );

            if(
                percentualAutomatico < 20 ||
                percentualAutomatico > 40
            ){
                throw new Error(
                    "A porcentagem calculada ficou fora de 20% a 40%. Confira os prints: o OCR pode ter perdido algum zero."
                );
            }

            /*
                O ganho do relatório segue a porcentagem normalizada.
                Isso evita que um pequeno erro de OCR altere o valor
                financeiro quando a taxa correta é, por exemplo, 20%.
            */
            const ganhoAutomatico =
                Number(
                    (
                        valorRecebido *
                        percentualAutomatico /
                        100
                    )
                    .toFixed(2)
                );

            console.log(
                "PORCENTAGEM AUTOMÁTICA:",
                {
                    percentualBruto,
                    percentualAutomatico,
                    distanciaDoInteiro,
                    ganhoAutomatico
                }
            );

            const resultadoFinal = {
                ...resultadoBase,

                data:
                    leituraRodape.data !== "---"
                        ? leituraRodape.data
                        : resultadoBase.data,

                percentualAutomatico,
                ganhoAutomatico,

                leituraDataHora:
                    leituraRodape.leitura,

                leituraOCR:
                    melhor.nome,

                pontuacaoOCR:
                    Number(
                        melhor.pontuacao
                            .toFixed(2)
                    ),

                confiancaTesseract:
                    Number(
                        melhor.confianca
                            .toFixed(2)
                    )
            };

            window.resultadoOCR =
                resultadoFinal;

            exibirResultadoOCR(
                resultadoFinal
            );

            const dadosParciais = [];

            if (
                !resultadoFinal.nome ||
                resultadoFinal.nome ===
                "Não identificado"
            ) {
                dadosParciais.push(
                    "nome"
                );
            }

            if (
                !resultadoFinal.idJogador ||
                resultadoFinal.idJogador ===
                "---"
            ) {
                dadosParciais.push(
                    "ID"
                );
            }

            if (
                dadosParciais.length > 0
            ) {
                alert(
                    "⚠️ O valor foi identificado, mas confira manualmente: " +
                    dadosParciais.join(
                        " e "
                    ) +
                    "."
                );
            }

            console.log(
                "RESULTADO FINAL DO OCR"
            );

            console.log(
                resultadoFinal
            );

            console.log(
                "OCR FINALIZADO COM SUCESSO"
            );
        }
        catch (erro) {
            console.error(
                "ERRO NO OCR:",
                erro
            );

            const mensagem =
                erro?.message ||
                "Erro desconhecido.";

            atualizarConsoleOCR(
                "Erro ao processar OCR:\n\n" +
                mensagem
            );

            alert(
                "❌ Erro ao processar OCR: " +
                mensagem
            );
        }
        finally {
            ocrEmProcessamento =
                false;

            atualizarBotaoProcessar(
                false
            );
        }
    }

    // =========================================================
    // EXPORTAÇÕES
    // =========================================================

    window.processarOCR =
        processarOCR;

    window.garantirTesseractCarregado =
        garantirTesseractCarregado;

    window.limparProcessamentoAnterior =
        limparProcessamentoAnterior;

    console.log(
        "OCR.JS v58 PRONTO"
    );
})();